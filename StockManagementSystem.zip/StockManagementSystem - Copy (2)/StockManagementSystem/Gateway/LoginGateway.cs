﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using StockManagementSystem.Model;

namespace StockManagementSystem.Gateway
{
     
    public class LoginGateway
    {
        Connection con=new Connection();       

        public List<Logins> GetLogin(string userName, string password)
        {
            string querry = "Select * From Users Where (UserName='" + userName + "'AND Password='" + password + "')";
            SqlCommand cmd = new SqlCommand(querry, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            List<Logins> logins = new List<Logins>();
            while (reader.Read())
            {
                Logins aLogins = new Logins();
                aLogins.UserName = reader["UserName"].ToString();
                aLogins.Password = reader["Password"].ToString();
                logins.Add(aLogins);
            }
            reader.Close();
            con.GetClose();
            return logins;
        }
    }
}