﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;

namespace StockManagementSystem.Gateway
{
    public class Connection
    {
        public SqlConnection connection;

        public SqlCommand Command { get; set; }
        public SqlDataReader Reader { get; set; }
        public string Query { get; set; }

        public SqlConnection GetConnection()
        {
            string connectionString =
                WebConfigurationManager.ConnectionStrings["StockManagementSystemConnectionString"].ConnectionString;
            connection = new SqlConnection(connectionString);
            if (connection != null)
            {
                connection.Close();
                connection.Open();
            }
            else
            {
                connection.Open();
            }
            return connection;
        }

        public void GetClose()
        {
            if (connection != null)
            {
                connection.Close();
            }
        }
    }
}