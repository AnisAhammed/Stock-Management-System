﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using StockManagementSystem.Model;

namespace StockManagementSystem.Gateway
{
    public class SearchGateway
    {
        Connection con = new Connection();

        public List<Items> GetAllSearch()
        {
            string querry = "Select * From SearchCompanyCategory";
            SqlCommand cmd = new SqlCommand(querry, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            List<Items> itemList = new List<Items>();
            while (reader.Read())
            {
                Items aItems = new Items();
                aItems.ItemNo = (int)reader["ItemNo"];
                aItems.ItemName = reader["ItemName"].ToString();
                aItems.CompanyName = reader["CompanyName"].ToString();
                aItems.CategoryName = reader["CategoryName"].ToString();
                aItems.ReorderLevel = (int)reader["ReorderLevel"];
                aItems.StockInQuantity = (int)reader["StockInQuantity"];
                itemList.Add(aItems);
            }
            reader.Close();
            con.GetClose();
            return itemList;
        }

        public List<Items> GetCompanySearch(string companySl)
        {
            string querry = "Select * From Item WHERE CompanySL='" + companySl + "'";
            SqlCommand cmd = new SqlCommand(querry, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            List<Items> itemList = new List<Items>();
            while (reader.Read())
            {
                Items aItems = new Items();
                aItems.ItemNo = (int)reader["ItemNo"];
                aItems.ItemName = reader["ItemName"].ToString();
                aItems.CompanySl = (int)reader["CompanySL"];
                aItems.CategorySl = (int)reader["CategorySL"];
                aItems.StockInQuantity = (int)reader["StockInQuantity"];
                aItems.ReorderLevel = (int)reader["ReorderLevel"];
                itemList.Add(aItems);
            }
            reader.Close();
            con.GetClose();
            return itemList;
        }

        public List<Items> GetCategorySearch(string categorySl)
        {
            string querry = "Select * From Item WHERE CategorySL='" + categorySl + "'";
            SqlCommand cmd = new SqlCommand(querry, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            List<Items> itemList = new List<Items>();
            while (reader.Read())
            {
                Items aItems = new Items();
                aItems.ItemNo = (int)reader["ItemNo"];
                aItems.ItemName = reader["ItemName"].ToString();
                aItems.CompanySl = (int)reader["CompanySL"];
                aItems.CategorySl = (int)reader["CategorySL"];
                aItems.StockInQuantity = (int)reader["StockInQuantity"];
                aItems.ReorderLevel = (int)reader["ReorderLevel"];
                itemList.Add(aItems);
            }
            reader.Close();
            con.GetClose();
            return itemList;
        }

        public List<ItemView> GetCompanyCategorySearch(string categoryName, string companyName)
        {
            string querry = "Select * From SearchCompanyCategory WHERE CategoryName='" + categoryName + "' OR CompanyName='" + companyName + "'";
            SqlCommand cmd = new SqlCommand(querry, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            List<ItemView> itemList = new List<ItemView>();
            while (reader.Read())
            {
                ItemView aItems = new ItemView();
                aItems.ItemNo = (int)reader["ItemNo"];
                aItems.ItemName = reader["ItemName"].ToString();
                aItems.CompanyName = reader["CompanyName"].ToString();
                aItems.CategoryName = reader["CategoryName"].ToString();
                aItems.StockInQuantity = (int)reader["StockInQuantity"];
                aItems.ReorderLevel = (int)reader["ReorderLevel"];
                itemList.Add(aItems);
            }
            reader.Close();
            con.GetClose();
            return itemList;
        }
    }
}