﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using StockManagementSystem.Model;

namespace StockManagementSystem.Gateway
{
    public class StockInGateway
    {
        Connection con = new Connection();

        public List<Items> GetItemNames(string companyName)
        {
            string query = "Select * From Item Where CompanySl='" + companyName + "'";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            List<Items> itemList = new List<Items>();
            while (reader.Read())
            {
                Items item = new Items();
                item.ItemNo = (int)reader["ItemNo"];
                item.ItemName = reader["ItemName"].ToString();
                item.ReorderLevel = (int)reader["ReorderLevel"];
                item.CategorySl = (int)reader["CategorySL"];
                item.CompanySl = (int)reader["CompanySL"];
                itemList.Add(item);
            }
            reader.Close();
            con.GetClose();
            return itemList;
        }

        public int GetReOrderLevel(int itemNo)
        {
            string query = "Select * from Item where ItemNo = '" + itemNo + "'";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            Items aItems = null;
            if (reader.HasRows)
            {
                reader.Read();
                aItems = new Items();
                aItems.ItemNo = (int) reader["ItemNo"];
                aItems.CategorySl = (int) reader["CategorySL"];
                aItems.CompanySl = (int) reader["CompanySL"];
                aItems.ItemName = reader["ItemName"].ToString();
                aItems.ReorderLevel = (int) reader["ReorderLevel"];
            }
            reader.Close();
            con.GetClose();
            return aItems.ReorderLevel;          
        }


        public int GetAvailableQuantity(int itemNo)
        {
            string query = "Select StockInQuantity from StockIn where ItemNo = '" + itemNo + "'";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            StockIns stockIn = new StockIns();
            stockIn.ItemNo = 0;
            while (reader.Read())
            {
                if (itemNo == stockIn.ItemNo)
                {
                    return stockIn.StockInQuantity;
                }
                stockIn.StockInQuantity = (int)reader["StockInQuantity"];

                stockIn.ItemNo++;
            }
            reader.Close();
            con.GetClose();
            return stockIn.StockInQuantity;
        }

        public bool StockIsExist(int stockInQuantity)
        {
            string query = "SELECT * FROM StockIn WHERE ItemNo='" + stockInQuantity + "'";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                con.GetClose();
                return true;
            }
            con.GetClose();
            return false;
        }

        public int GetStock(StockIns aStockIn)
        {
            string query = "Select StockInQuantity from StockIn where ItemNo='" + aStockIn.ItemNo + "'";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                int stock = (int)reader["StockInQuantity"];
                reader.Close();
                con.GetClose();

                stock = stock + aStockIn.StockInQuantity;
                string newQuery = "update StockIn set StockInQuantity = '" + stock + "' WHERE ItemNo='" + aStockIn.ItemNo + "'";
                SqlCommand cmd1 = new SqlCommand(newQuery, con.GetConnection());
                int rowCount = cmd1.ExecuteNonQuery();
                con.GetClose();
                return rowCount;
            }
            return 0;
        }

        public int Save(StockIns aStockIn)
        {
            string query = "INSERT INTO StockIn(CompanySL,ItemNo,StockInQuantity) Values('" +
                            aStockIn.CompanySl + "','" + aStockIn.ItemNo + "','" + aStockIn.StockInQuantity + "')";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            int rowCount = cmd.ExecuteNonQuery();
            con.GetClose();
            return rowCount;
        }

   
    }
}