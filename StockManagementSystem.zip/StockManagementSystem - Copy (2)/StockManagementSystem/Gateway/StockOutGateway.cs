﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using StockManagementSystem.Model;

namespace StockManagementSystem.Gateway
{
    public class StockOutGateway
    {
        Connection con = new Connection();

        public List<Items> GetItemNames(string companyName)
        {
            string query = "Select * From Item Where CompanySL='" + companyName + "'";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            List<Items> itemList = new List<Items>();
            while (reader.Read())
            {
                Items item = new Items();
                item.ItemNo = (int)reader["ItemNo"];
                item.ItemName = reader["ItemName"].ToString();
                item.ReorderLevel = (int)reader["ReorderLevel"];
                item.CategorySl = (int)reader["CategorySL"];
                item.CompanySl = (int)reader["CompanySL"];
                itemList.Add(item);
            }
            reader.Close();
            con.GetClose();
            return itemList;
        }       

        public bool StockIsExist(int stockOutQuantity)
        {
            string query = "SELECT * FROM StockOut WHERE ItemNo='" + stockOutQuantity + "'";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                con.GetClose();
                return true;
            }
            con.GetClose();
            return false;
        }

        public int GetStock(StockOuts aStockOuts)
        {
            string query = "Select StockInQuantity from StockIn where ItemNo='" + aStockOuts.ItemNo + "'";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                reader.Read();
                int stock = (int)reader["StockInQuantity"];
                reader.Close();
                con.GetClose();

                
                stock = stock - aStockOuts.StockOutQuantity;
                string newQuery = "update StockIn set StockInQuantity = '" + stock + "' WHERE ItemNo='" + aStockOuts.ItemNo + "'";
                SqlCommand cmd1 = new SqlCommand(newQuery, con.GetConnection());
                int rowCount = cmd1.ExecuteNonQuery();
                con.GetClose();
                return rowCount;
            }
            return 0;
        }

        public int Save(StockOuts aStockOuts)
        {
            string query = "INSERT INTO StockOut(CompanySL,ItemNo,StockOutQuantity) Values('" +
                            aStockOuts.CompanySl + "','" + aStockOuts.ItemNo + "','" + aStockOuts.StockOutQuantity + "')";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            int rowCount = cmd.ExecuteNonQuery();
            con.GetClose();
            return rowCount;
        }

        public int Save1(StockOuts aStockOuts)
        {
            string query = "INSERT INTO StockOut(CompanySL,ItemNo,StockOutQuantity,Type,Date) Values('" +
                            aStockOuts.CompanySl + "','" + aStockOuts.ItemNo + "','" + aStockOuts.StockOutQuantity + "','Sell','" + aStockOuts.Date + "')";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            int rowCount = cmd.ExecuteNonQuery();
            con.GetClose();
            return rowCount;
        }

        public int Save2(StockOuts aStockOuts)
        {
            string query = "INSERT INTO StockOut(CompanySL,ItemNo,StockOutQuantity,Type,Date) Values('" +
                            aStockOuts.CompanySl + "','" + aStockOuts.ItemNo + "','" + aStockOuts.StockOutQuantity + "','Damage','" + aStockOuts.Date + "')";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            int rowCount = cmd.ExecuteNonQuery();
            con.GetClose();
            return rowCount;
        }

        public int Save3(StockOuts aStockOuts)
        {
            string query = "INSERT INTO StockOut(CompanySL,ItemNo,StockOutQuantity,Type,Date) Values('" +
                            aStockOuts.CompanySl + "','" + aStockOuts.ItemNo + "','" + aStockOuts.StockOutQuantity + "','Lost','" + aStockOuts.Date + "')";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            int rowCount = cmd.ExecuteNonQuery();
            con.GetClose();
            return rowCount;
        }
    }
}