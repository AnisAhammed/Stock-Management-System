﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using StockManagementSystem.Form;
using StockManagementSystem.Model;
using SearchDate = StockManagementSystem.Model.SearchDates;

namespace StockManagementSystem.Gateway
{
    public class SearchDateGateway
    {
        Connection con=new Connection();

        public List<SearchDate> GetAllSales()
        {
            string query = "SELECT * FROM SalesReport";
            SqlCommand cmd=new SqlCommand(query,con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            List<SearchDate> dateList = new List<SearchDate>();
            while (reader.Read())
            {
                SearchDate aSearchDate = new SearchDate();
                aSearchDate.ItemName = reader["ItemName"].ToString();
                aSearchDate.SalesQuantity = (int)reader["SalesQuantity"];
                aSearchDate.Type = reader["Type"].ToString();              
                dateList.Add(aSearchDate);
            }
            reader.Close();
            con.GetClose();
            return dateList;
        }

        public List<SearchDate> GetSalesReport(string fromDate, string toDate)
        {           
            string query = "Select * From SalesReport WHERE Date BETWEEN '" + fromDate + "' AND '" + toDate + "'";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            List<SearchDate> resultLists = new List<SearchDate>();
            while (reader.Read())
            {
                SearchDate salesList = new SearchDate();
                salesList.ItemName = (string)reader["ItemName"];
                salesList.SalesQuantity = (int)reader["SalesQuantity"];

                resultLists.Add(salesList);
            }
            reader.Close();
            con.GetClose();
            return resultLists;
        }
    }
}