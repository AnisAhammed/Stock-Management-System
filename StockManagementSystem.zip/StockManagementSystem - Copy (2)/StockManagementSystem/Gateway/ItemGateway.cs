﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using StockManagementSystem.Model;

namespace StockManagementSystem.Gateway
{
    public class ItemGateway
    {       
        Connection con=new Connection();

        public bool IsExit(string itemName)
        {
            string querry = "SELECT * FROM Item WHERE ItemName='" + itemName + "'";
            SqlCommand cmd = new SqlCommand(querry, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                return true;
            }
            return false;
        }
        public int Save(Items aItem)
        {
            string query = "INSERT INTO Item(CategorySL, CompanySL, ItemName,ReorderLevel ) Values('" +
            aItem.CategorySl + "','" + aItem.CompanySl + "','" + aItem.ItemName + "','" + aItem.ReorderLevel + "')";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            int rowCount = cmd.ExecuteNonQuery();
            con.GetClose();
            return rowCount;
        }

        public List<Items> GetAllItems()
        {
            string query = "Select * From Item";
            SqlCommand cmd=new SqlCommand(query,con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            List<Items> itemList=new List<Items>();
            while (reader.Read())
            {
                Items aItems=new Items();
                aItems.ItemNo = (int) reader["ItemNo"];
                aItems.CategorySl = (int) reader["CategorySL"];
                aItems.CompanySl = (int) reader["CompanySL"];
                aItems.ItemName = reader["ItemName"].ToString();
                aItems.ReorderLevel = (int) reader["ReorderLevel"];
                itemList.Add(aItems);
            }
            reader.Close();
            con.GetClose();
            return itemList;
        }

        public List<ItemView> GetAllItemsView()
        {
            string query = "Select * From SearchCompanyCategory";
            SqlCommand cmd = new SqlCommand(query, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            List<ItemView> itemList = new List<ItemView>();
            while (reader.Read())
            {
                ItemView aItems = new ItemView();
                //aItems.ItemNo = (int)reader["ItemNo"];
                aItems.CategoryName = reader["CategoryName"].ToString();
                aItems.CompanyName = reader["CompanyName"].ToString();
                aItems.ItemName = reader["ItemName"].ToString();
                aItems.ReorderLevel = (int)reader["ReorderLevel"];
                aItems.StockInQuantity = (int)reader["StockInQuantity"];
                itemList.Add(aItems);
            }
            reader.Close();
            con.GetClose();
            return itemList;
        }
    }
}