﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using StockManagementSystem.Form;
using StockManagementSystem.Model;

namespace StockManagementSystem.Gateway
{
    public class CategoryGateway
    {
        Connection con = new Connection();
        
        public bool IsExit(string categoryName)
        {
            string querry = "SELECT * FROM Category WHERE CategoryName='" + categoryName + "'";
            SqlCommand cmd = new SqlCommand(querry, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                return true;
            }
            return false;
        }
        public int Save(Categorys aCategory)
        {
            string querry = "INSERT INTO Category(CategoryName) Values('" +
            aCategory.CategoryName + "')";
            SqlCommand cmd = new SqlCommand(querry, con.GetConnection());
            int rowCount = cmd.ExecuteNonQuery();
            con.GetClose();
            return rowCount;
        }

        public List<Categorys> GetAllCategory()
        {
            string querry = "SELECT * FROM  Category";
            SqlCommand cmd = new SqlCommand(querry, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            List<Categorys> categorysList = new List<Categorys>();
            while (reader.Read())
            {
                Categorys aCategorys = new Categorys();
                aCategorys.Sl = Convert.ToInt32(reader["SL"].ToString());
                aCategorys.CategoryName = reader["CategoryName"].ToString();
                categorysList.Add(aCategorys);
            }
            reader.Close();
            con.GetClose();
            return categorysList;
        }

        public int UpdateCategory(Categorys aCategorys)
        {
            string querry = "UPDATE Category SET CategoryName='" + aCategorys.CategoryName + "' WHERE SL = '" + aCategorys.Sl + "'";
            SqlCommand cmd = new SqlCommand(querry, con.GetConnection());
            int rowCount = cmd.ExecuteNonQuery();
            con.GetClose();
            return rowCount;
        }
    }
}