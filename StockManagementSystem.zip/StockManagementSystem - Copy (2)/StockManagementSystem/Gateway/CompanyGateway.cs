﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using StockManagementSystem.Model;

namespace StockManagementSystem.Gateway
{
    public class CompanyGateway
    {
        Connection con=new Connection();

        public bool IsExit(string companyName)
        {
            string querry = "SELECT * FROM Company WHERE CompanyName='" + companyName + "'";
            SqlCommand cmd = new SqlCommand(querry, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                return true;
            }
            return false;
        }

        public int Save(Companys aCompanys)
        {            
            string querry = "INSERT INTO Company(CompanyName) Values('" +
            aCompanys.CompanyName + "')";
            SqlCommand cmd = new SqlCommand(querry, con.GetConnection());
            int rowCount = cmd.ExecuteNonQuery();
            con.GetClose();
            return rowCount;
        }

        public List<Companys> GetAllCompany()
        {           
            string querry = "SELECT * FROM  Company";
            SqlCommand cmd = new SqlCommand(querry, con.GetConnection());
            SqlDataReader reader = cmd.ExecuteReader();
            List<Companys> companyList = new List<Companys>();
            while (reader.Read())
            {
                Companys aCompanys = new Companys();
                aCompanys.Sl = Convert.ToInt32(reader["SL"].ToString());
                aCompanys.CompanyName = reader["CompanyName"].ToString();
                companyList.Add(aCompanys);
            }
            reader.Close();
            con.GetClose();
            return companyList;
        }
    }
}