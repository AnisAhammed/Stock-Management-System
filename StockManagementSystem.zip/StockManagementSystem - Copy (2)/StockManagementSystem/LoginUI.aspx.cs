﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using StockManagementSystem.BLL;
using StockManagementSystem.Gateway;
using StockManagementSystem.Model;

namespace StockManagementSystem
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        LoginManager aLoginManager = new LoginManager();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogIn_Click(object sender, EventArgs e)
        {
            //try
            //{
                Logins aLogins = new Logins();
                aLogins.UserName = txtUserName.Text;
                aLogins.Password = txtPassword.Text;

                List<Logins> data=aLoginManager.GetLogin(aLogins.UserName, aLogins.Password);
                if (data.Count>0)
                {
                    Response.Redirect("Form/HomeForm.aspx");
                }
                else
                {
                    Literal1.Text = "UserName OR Password Wrong";
                }

            //catch (Exception ex1)
            //{
            //    Literal1.Text = ex1.Message;
            //}
        }

    }
}