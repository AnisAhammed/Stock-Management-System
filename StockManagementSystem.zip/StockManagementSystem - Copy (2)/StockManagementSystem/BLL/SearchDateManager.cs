﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using StockManagementSystem.Gateway;
using StockManagementSystem.Model;

namespace StockManagementSystem.BLL
{
    
    public class SearchDateManager
    {
        SearchDateGateway aSearchDateGateway=new SearchDateGateway();


        public List<SearchDates> GetAllSales()
        {
            return aSearchDateGateway.GetAllSales();
        }

        public List<SearchDates> GetSalesReport(string fromDate, string toDate)
        {
            return aSearchDateGateway.GetSalesReport(fromDate, toDate);
        }
    }
}