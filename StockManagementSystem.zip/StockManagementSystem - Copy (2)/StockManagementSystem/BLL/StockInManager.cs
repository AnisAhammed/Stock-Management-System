﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using StockManagementSystem.Gateway;
using StockManagementSystem.Model;

namespace StockManagementSystem.BLL
{
    public class StockInManager
    {
        StockInGateway aStockInGateway = new StockInGateway();

        public List<Items> GetItemNames(string companyName)
        {
            return aStockInGateway.GetItemNames(companyName);
        }

        public int GetReOrderLevel(int itemNo)
        {
            return aStockInGateway.GetReOrderLevel(itemNo);
        }

        public int GetAvailableQuantity(int itemNo)
        {
            if (StockIsExist(itemNo))
            {
                return aStockInGateway.GetAvailableQuantity(itemNo);
            }
            return 0;
        }

        public bool StockIsExist(int stockInQuantity)
        {
            return aStockInGateway.StockIsExist(stockInQuantity);
        }

        public string Save(StockIns aStockIn)
        {
            if (aStockIn.StockInQuantity > 0)
            {

                if (!StockIsExist(aStockIn.ItemNo))
                {
                    int rowAffected = aStockInGateway.Save(aStockIn);
                    if (rowAffected > 0)
                    {

                        return "Save Successfully";
                    }
                    else
                    {
                        return "Failed to save";

                    }
                }
                else
                {

                    int update = aStockInGateway.GetStock(aStockIn);
                    if (update > 0)
                    {
                        return "Product Update Successfully";
                    }
                    else
                    {
                        return "Failed to stock update";
                    }

                }

            }

            return "Provide positive value";
        }
    }
}