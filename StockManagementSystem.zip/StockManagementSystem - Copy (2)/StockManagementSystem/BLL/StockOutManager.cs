﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using StockManagementSystem.Gateway;
using StockManagementSystem.Model;

namespace StockManagementSystem.BLL
{
    public class StockOutManager
    {
        StockOutGateway aStockOutGateway = new StockOutGateway();
        StockInGateway aStockInGateway = new StockInGateway();

        public List<Items> GetItemNames(string companyName)
        {
            return aStockOutGateway.GetItemNames(companyName);
        }
       
        public bool StockIsExist(int stockOutQuantity)
        {
            return aStockOutGateway.StockIsExist(stockOutQuantity);
        }

        public string Save(StockOuts aStockOuts)
        {
            if (aStockOuts.StockOutQuantity > 0)
            {
                if (StockIsExist(aStockOuts.StockOutQuantity))
                {
                    int update = aStockOutGateway.GetStock(aStockOuts);
                    if (update > 0)
                    {
                        return "Product Update Successfully";
                    }
                    else
                    {
                        return "Failed to stock update";
                    }
                }

                int rowAffected = aStockOutGateway.Save(aStockOuts);
                if (rowAffected > 0)
                {
                    return "Save Successfully";
                }
                return "Failed to save";
            }
            return "Provide positive value";
        }

        

        public string Save1(StockOuts aStockOuts)
        {
            int rowAffected = aStockOutGateway.Save1(aStockOuts);
            if (rowAffected > 0)
            {
                return "Save Successfully";
            }
            else
            {
                return "Failed to save";
            }
        }

        public string Save2(StockOuts aStockOuts)
        {
            int rowAffected = aStockOutGateway.Save2(aStockOuts);
            if (rowAffected > 0)
            {
                return "Save Successfully";
            }
            else
            {
                return "Failed to save";
            }
        }

        public string Save3(StockOuts aStockOuts)
        {
            int rowAffected = aStockOutGateway.Save3(aStockOuts);
            if (rowAffected > 0)
            {
                return "Save Successfully";
            }
            else
            {
                return "Failed to save";
            }
        }
    }
}