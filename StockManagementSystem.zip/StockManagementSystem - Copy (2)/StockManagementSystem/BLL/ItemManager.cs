﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using StockManagementSystem.Gateway;
using StockManagementSystem.Model;

namespace StockManagementSystem.BLL
{
    public class ItemManager
    {
        ItemGateway aItemGateway=new ItemGateway();

        public bool IsExit(string itemName)
        {
            return aItemGateway.IsExit(itemName);
        }

        public string Save(Items aItem)
        {
            if (IsExit(aItem.ItemName))
            {
                return "Already This Item Name exit!!!";
            }
            int rowAffected = aItemGateway.Save(aItem);
            if (rowAffected > 0)
            {
                return "Save Item Name successfully!!!";
            }
            return "Not Save Successfully!!!";
        }

        public List<Items> GetAllItems()
        {
            return aItemGateway.GetAllItems();
        }

        public List<ItemView> GetAllItemsView()
        {
            return aItemGateway.GetAllItemsView();
        }
    }
}