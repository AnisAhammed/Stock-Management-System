﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using StockManagementSystem.Gateway;
using StockManagementSystem.Model;

namespace StockManagementSystem.BLL
{
    public class CompanyManager
    {
        CompanyGateway aCompanyGateway=new CompanyGateway();

        public bool IsExit(string companyName)
        {
            return aCompanyGateway.IsExit(companyName);
        }
        public string Save(Companys aCompanys)
        {
            if (IsExit(aCompanys.CompanyName))
            {
                return "Already This Company Name Exit!";
            }
            int rowAffected = aCompanyGateway.Save(aCompanys);
            if (rowAffected > 0)
            {
                return "Save Successfully";
            }
            return "Not Save Successfully";
        }

        public List<Companys> GetAllCompany()
        {
            List<Companys> company = aCompanyGateway.GetAllCompany();
            return company;
        }
    }
}