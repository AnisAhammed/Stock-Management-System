﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using StockManagementSystem.Form;
using StockManagementSystem.Gateway;
using StockManagementSystem.Model;

namespace StockManagementSystem.BLL
{

    public class CategoryManager
    {
        CategoryGateway aCategoryGateway = new CategoryGateway();

        public bool IsExit(string categoryName)
        {
            return aCategoryGateway.IsExit(categoryName);
        }
        public string Save(Categorys aCategory)
        {
            if (IsExit(aCategory.CategoryName))
            {
                return "Already This Item Name exit!!!";
            }
            int rowAffected = aCategoryGateway.Save(aCategory);
            if (rowAffected > 0)
            {
                return "Save Item Name successfully!!!";
            }
            return "Not Save Successfully!!!";
        }

        public List<Categorys> GetAllCategory()
        {
            List<Categorys> categorys = aCategoryGateway.GetAllCategory();
            return categorys;
        }

        public string UpdateCategory(Categorys aCategorys)
        {
            if (IsExit(aCategorys.CategoryName))
            {
                return "Already This name exit!";
            }
            int rowCount = aCategoryGateway.UpdateCategory(aCategorys);
            if (rowCount > 0)
            {
                return "Category Has been updated";
            }
            return "Category Not Updated";
        }
    }
}