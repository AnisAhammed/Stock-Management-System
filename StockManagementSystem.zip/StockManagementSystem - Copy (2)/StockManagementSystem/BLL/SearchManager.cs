﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using StockManagementSystem.Gateway;
using StockManagementSystem.Model;

namespace StockManagementSystem.BLL
{
    public class SearchManager
    {
        SearchGateway aSearchGateway=new SearchGateway();

        public List<Items> GetAllSearch()
        {
            return aSearchGateway.GetAllSearch();
        }

        public List<Items> GetCompanySearch(string companySl)
        {
            return aSearchGateway.GetCompanySearch(companySl);
        }

        public List<Items> GetCategorySearch(string categorySl)
        {
            return aSearchGateway.GetCategorySearch(categorySl);
        }

        public List<ItemView> GetCompanyCategorySearch(string categorySl, string companySl)
        {
            return aSearchGateway.GetCompanyCategorySearch(categorySl, companySl);
        }
    }
}