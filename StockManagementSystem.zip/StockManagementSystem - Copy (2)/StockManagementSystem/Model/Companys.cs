﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StockManagementSystem.Model
{
    public class Companys
    {
        public int Sl { get; set; }
        public string CompanyName { get; set; }
    }
}