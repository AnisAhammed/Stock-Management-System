﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StockManagementSystem.Model
{
    public class Items
    {
        public int ItemNo { get; set; }
        public int CategorySl { get; set; }
        public string CategoryName { get; set; }
        public int CompanySl { get; set; }
        public string CompanyName { get; set; }
        public string ItemName { get; set; }
        public int ReorderLevel { get; set; }
        public int AvailableQuantity { get; set; }
        public int StockInQuantity { get; set; }
    }
}