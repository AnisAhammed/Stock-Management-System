﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StockManagementSystem.Model
{
    public class SearchDates
    {
        public int StockOutNo { get; set; }
        public int CompanySl { get; set; }
        public int ItemNo { get; set; }
        public string ItemName { get; set; }
        public int AvailableQuantity { get; set; }
        public int StockOutQuantity { get; set; }
        public int SalesQuantity { get; set; }
        public string Type { get; set; }
        public string Date { get; set; }
    }
}