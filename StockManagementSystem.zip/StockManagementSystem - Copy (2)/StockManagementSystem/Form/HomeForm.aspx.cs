﻿using System;
using System.Web.UI;

namespace StockManagementSystem.Form
{
    public partial class HomeForm : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}